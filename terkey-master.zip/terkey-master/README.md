# terkey


pkg update && pkg upgrade

git clone https://github.com/M3C4NIX/terkey

python2 terkey.py

enjoy....
